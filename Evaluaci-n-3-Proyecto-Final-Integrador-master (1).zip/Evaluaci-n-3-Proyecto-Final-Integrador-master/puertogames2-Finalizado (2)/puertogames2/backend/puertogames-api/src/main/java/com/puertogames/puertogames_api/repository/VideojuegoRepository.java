package com.puertogames.puertogames_api.repository;
import com.puertogames.puertogames_api.model.Videojuego;
import org.springframework.data.jpa.repository.JpaRepository;
public interface VideojuegoRepository extends JpaRepository<Videojuego, Long> {
}
